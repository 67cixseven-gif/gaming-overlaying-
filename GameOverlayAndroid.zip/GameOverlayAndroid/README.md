# Game Overlay — Android Gaming Mode (Kotlin)

A floating gaming toolkit for Android: draggable/minimizable overlay bubble with a
tabbed tools panel — game boosters, a key mapper that injects taps into the running
game, speech-to-text, a mini in-game keyboard (IME), and floating mini windows for
Discord, Telegram, WhatsApp, a browser and a calculator.

## Features

- **Floating bubble** — draggable anywhere, tap to expand the panel, "—" minimizes back to the bubble, "✕" stops the overlay.
- **Boost tab** — live RAM stats, one-tap background-app cleanup, gaming Do-Not-Disturb toggle.
- **Keys tab** — map named buttons (Jump, Fire, …) to exact screen coordinates. Pressing a mapped key injects a real tap into the game via the accessibility service. Mappings persist between sessions.
- **Voice tab** — speech-to-text with live partial results; copy to clipboard or insert into any text field with the GameKeyboard IME.
- **Apps tab** — floating, draggable mini windows: Discord (discord.com), Telegram (web.telegram.org), WhatsApp (web.whatsapp.com, desktop UA), a free-form browser with URL bar, and a calculator.
- **GameKeyboard IME** — chat macros (GG / Nice! / BRB), one-tap insert of the last voice result, and a keyboard-switcher button.

## How to build the APK (no coding required)

1. Install **Android Studio** (free): https://developer.android.com/studio
2. Unzip this project, then in Android Studio: **File → Open** → select the `GameOverlayAndroid` folder.
3. Wait for the Gradle sync to finish (Android Studio downloads the build tools automatically).
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Click **locate** in the notification — `app-debug.apk` is ready to copy to your phone.

Command line alternative (with Android SDK + Gradle installed): `gradle wrapper` once, then `./gradlew assembleDebug`.

## First-run setup on the phone

1. Open the app and tap the buttons in order:
   - **Display over other apps** (required for the floating bubble)
   - **Microphone** (voice typing)
   - **Accessibility** → enable **Game Overlay** (required for key mapping into games)
2. Optional: **System → Languages → On-screen keyboard** → enable **GameKeyboard**.
3. Tap **Start gaming overlay**, then switch to your game.

## Honest limitations (Android platform rules)

- **Key mapping** only works through the accessibility gesture API — that's why step 3 is mandatory. It injects taps at fixed coordinates; per-game button layouts must be mapped manually.
- **RAM boosting** is limited by Android: the app can ask the system to close background apps but cannot force-kill foreground or system apps.
- **Discord / Telegram / WhatsApp** run as their *web* versions inside a WebView. Voice/video calls may not work in-app; WhatsApp needs a one-time QR pairing.
- **Voice typing into games** requires switching to the GameKeyboard IME while typing (Android does not allow injecting text into apps without an IME).
- `QUERY_ALL_PACKAGES` is declared so Boost can see installed apps. This is fine for side-loading, but Google Play requires justification for this permission if you publish.

## Project structure

```
app/src/main/java/com/gameoverlay/
├── MainActivity.kt                 # setup screen + permissions
├── overlay/
│   ├── OverlayService.kt           # foreground service, bubble + tabbed panel
│   ├── DraggableTouchListener.kt   # drag-anywhere behavior for all windows
│   ├── FloatingWebWindow.kt        # Discord / Telegram / WhatsApp / browser
│   └── CalcWindow.kt               # floating calculator + expression parser
├── boost/BoostManager.kt           # RAM stats, background cleanup, DND
├── keys/
│   ├── KeyMapper.kt                # mapping storage (JSON SharedPreferences)
│   └── KeyMapperService.kt         # accessibility service: gesture injection
├── voice/VoiceTypingController.kt  # SpeechRecognizer wrapper
└── ime/GameKeyboardService.kt      # in-game macro keyboard (IME)
```
