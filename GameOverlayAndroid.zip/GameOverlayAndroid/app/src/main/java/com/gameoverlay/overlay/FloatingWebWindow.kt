package com.gameoverlay.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import com.gameoverlay.R

/** Common contract for mini floating windows (web apps, calculator, ...). */
interface FloatingWindow {
    fun show()
    fun dismiss()
}

/**
 * Draggable, closable mini window hosting a WebView — used for Discord,
 * Telegram, WhatsApp and the free-form browser.
 */
class FloatingWebWindow(
    private val context: Context,
    private val wm: WindowManager,
    private val title: String,
    private val startUrl: String,
    private val showUrlBar: Boolean = false
) : FloatingWindow {

    private var view: View? = null

    override fun show() {
        if (view != null) return
        val v = LayoutInflater.from(context).inflate(R.layout.floating_web, null)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 240
        }

        v.findViewById<TextView>(R.id.webTitle).text = title
        v.findViewById<View>(R.id.webHeader)
            .setOnTouchListener(DraggableTouchListener(wm, v, lp) {})
        v.findViewById<Button>(R.id.webClose).setOnClickListener { dismiss() }

        val web = v.findViewById<WebView>(R.id.webView)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        if (startUrl.contains("whatsapp")) {
            // WhatsApp Web refuses mobile user agents
            web.settings.userAgentString =
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
        }
        web.webViewClient = WebViewClient()
        web.loadUrl(startUrl)

        if (showUrlBar) {
            v.findViewById<LinearLayout>(R.id.urlBar).visibility = View.VISIBLE
            val input = v.findViewById<EditText>(R.id.urlInput)
            v.findViewById<Button>(R.id.urlGo).setOnClickListener {
                var url = input.text.toString().trim()
                if (url.isNotEmpty()) {
                    if (!url.startsWith("http")) url = "https://$url"
                    web.loadUrl(url)
                }
            }
        }

        wm.addView(v, lp)
        view = v
    }

    override fun dismiss() {
        view?.let { runCatching { wm.removeView(it) } }
        view = null
    }
}
