package com.gameoverlay.ime

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import com.gameoverlay.R

/**
 * Minimal in-game keyboard (IME) with chat macros and a key that inserts
 * the last voice-typing result. Enable it in System → Languages →
 * On-screen keyboard, then switch to it while gaming.
 */
class GameKeyboardService : InputMethodService() {

    override fun onCreateInputView(): View {
        val view = layoutInflater.inflate(R.layout.ime_view, null)

        fun commit(text: String) {
            currentInputConnection?.commitText(text, 1)
        }

        view.findViewById<Button>(R.id.keyGg).setOnClickListener { commit("GG ") }
        view.findViewById<Button>(R.id.keyNice).setOnClickListener { commit("Nice! ") }
        view.findViewById<Button>(R.id.keyBrb).setOnClickListener { commit("BRB ") }
        view.findViewById<Button>(R.id.keyVoice).setOnClickListener {
            val last = getSharedPreferences("voice", MODE_PRIVATE)
                .getString("last_text", "") ?: ""
            if (last.isNotEmpty()) commit(last)
        }
        view.findViewById<Button>(R.id.keySwitch).setOnClickListener {
            getSystemService(InputMethodManager::class.java)?.showInputMethodPicker()
        }

        return view
    }
}
