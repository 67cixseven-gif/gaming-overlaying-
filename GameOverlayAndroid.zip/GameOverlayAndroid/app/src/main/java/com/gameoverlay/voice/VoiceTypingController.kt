package com.gameoverlay.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Wraps Android SpeechRecognizer for the panel's sound-to-text feature. */
class VoiceTypingController(
    private val context: Context,
    private val onText: (text: String, isFinal: Boolean) -> Unit
) {

    private var recognizer: SpeechRecognizer? = null

    var listening = false
        private set

    fun start() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onText("Speech recognition is not available on this device", true)
            return
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle) {
                    val text = results
                        .getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        .orEmpty()
                    onText(text, true)
                    listening = false
                }

                override fun onPartialResults(partialResults: Bundle) {
                    val text = partialResults
                        .getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        .orEmpty()
                    if (text.isNotEmpty()) onText(text, false)
                }

                override fun onError(error: Int) {
                    onText("Voice error ($error) — tap start to retry", true)
                    listening = false
                }

                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        recognizer?.startListening(intent)
        listening = true
    }

    fun stop() {
        recognizer?.stopListening()
        listening = false
    }

    fun destroy() {
        recognizer?.destroy()
        recognizer = null
        listening = false
    }
}
