package com.gameoverlay.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.gameoverlay.MainActivity
import com.gameoverlay.R
import com.gameoverlay.boost.BoostManager
import com.gameoverlay.keys.KeyMapper
import com.gameoverlay.keys.KeyMapperService
import com.gameoverlay.keys.KeyMapping
import com.gameoverlay.voice.VoiceTypingController

/**
 * Foreground service owning all floating UI: the draggable bubble, the
 * tabbed tools panel, key-capture overlay and mini app windows.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.gameoverlay.action.STOP"
    }

    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var captureView: View? = null
    private var voice: VoiceTypingController? = null
    private val floatingWindows = mutableListOf<FloatingWindow>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startAsForeground()
        showBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        hideBubble()
        hidePanel()
        captureView?.let { runCatching { wm.removeView(it) } }
        captureView = null
        floatingWindows.toList().forEach { it.dismiss() }
        floatingWindows.clear()
        voice?.destroy()
        voice = null
        super.onDestroy()
    }

    private fun startAsForeground() {
        val channelId = "overlay_channel"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Game Overlay", NotificationManager.IMPORTANCE_LOW)
        )
        val contentIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("Game Overlay is running")
            .setContentText("Tap the floating bubble to open gaming tools")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(contentIntent)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notification)
        }
    }

    private fun params(width: Int, height: Int, flags: Int, x: Int, y: Int) =
        WindowManager.LayoutParams(
            width, height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
        }

    // ---------- Bubble ----------

    private fun showBubble() {
        if (bubble != null) return
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_bubble, null)
        val lp = params(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            24, 220
        )
        view.setOnTouchListener(DraggableTouchListener(wm, view, lp) {
            hideBubble()
            showPanel()
        })
        wm.addView(view, lp)
        bubble = view
    }

    private fun hideBubble() {
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
    }

    // ---------- Panel ----------

    private fun showPanel() {
        if (panel != null) return
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_panel, null)
        val lp = params(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            16, 120
        )
        view.findViewById<View>(R.id.panelHeader)
            .setOnTouchListener(DraggableTouchListener(wm, view, lp) {})
        view.findViewById<Button>(R.id.btnMinimize).setOnClickListener {
            hidePanel()
            showBubble()
        }
        view.findViewById<Button>(R.id.btnClose).setOnClickListener { stopSelf() }
        setupTabs(view)
        setupBoost(view)
        setupKeys(view)
        setupVoice(view)
        setupApps(view)
        wm.addView(view, lp)
        panel = view
    }

    private fun hidePanel() {
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
    }

    private fun setupTabs(view: View) {
        val tabs = mapOf(
            R.id.tabBtnBoost to R.id.tabBoost,
            R.id.tabBtnKeys to R.id.tabKeys,
            R.id.tabBtnVoice to R.id.tabVoice,
            R.id.tabBtnApps to R.id.tabApps
        )
        tabs.forEach { (buttonId, tabId) ->
            view.findViewById<Button>(buttonId).setOnClickListener {
                tabs.values.forEach { id ->
                    view.findViewById<View>(id).visibility =
                        if (id == tabId) View.VISIBLE else View.GONE
                }
            }
        }
    }

    // ---------- Boost tab ----------

    private fun setupBoost(view: View) {
        val memText = view.findViewById<TextView>(R.id.memText)
        val refresh = { memText.text = BoostManager.memorySummary(this) }
        refresh()
        view.findViewById<Button>(R.id.btnBoost).setOnClickListener {
            toast(BoostManager.boost(this))
            refresh()
        }
        view.findViewById<Button>(R.id.btnRefreshMem).setOnClickListener { refresh() }
        view.findViewById<Button>(R.id.btnDnd).setOnClickListener {
            toast(BoostManager.toggleDnd(this))
        }
    }

    // ---------- Keys tab ----------

    private fun setupKeys(view: View) {
        val list = view.findViewById<LinearLayout>(R.id.keysList)
        lateinit var render: () -> Unit
        render = {
            list.removeAllViews()
            val mappings = KeyMapper.load(this)
            if (mappings.isEmpty()) {
                list.addView(TextView(this).apply {
                    text = "No keys mapped yet"
                    setTextColor(0xFF9AA0AA.toInt())
                    setPadding(8, 8, 8, 8)
                })
            }
            mappings.forEach { mapping ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                row.addView(Button(this).apply {
                    text = "${mapping.label} → (${mapping.x}, ${mapping.y})"
                    layoutParams = LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
                    )
                    setOnClickListener {
                        val service = KeyMapperService.instance
                        if (service == null) {
                            toast("Enable 'Game Overlay' in Accessibility settings first")
                        } else {
                            service.performTap(mapping.x, mapping.y)
                        }
                    }
                })
                row.addView(Button(this).apply {
                    text = "✕"
                    setOnClickListener {
                        KeyMapper.remove(this@OverlayService, mapping.label)
                        render()
                    }
                })
                list.addView(row)
            }
        }
        render()
        view.findViewById<Button>(R.id.btnAddKey).setOnClickListener { startKeyCapture(render) }
    }

    /** Full-screen capture: type a key name, tap the touch point to bind. */
    private fun startKeyCapture(onDone: () -> Unit) {
        if (captureView != null) return
        val view = LayoutInflater.from(this).inflate(R.layout.key_capture, null)
        val lp = params(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            0, 0
        )
        val labelInput = view.findViewById<EditText>(R.id.keyLabelInput)
        view.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                val label = labelInput.text.toString().trim().ifBlank { "Key" }
                KeyMapper.add(
                    this,
                    KeyMapping(label, event.rawX.toInt(), event.rawY.toInt())
                )
                runCatching { wm.removeView(view) }
                captureView = null
                toast("Mapped '$label' to (${event.rawX.toInt()}, ${event.rawY.toInt()})")
                onDone()
                true
            } else {
                false
            }
        }
        wm.addView(view, lp)
        captureView = view
        toast("Type a key name, then tap the screen spot it should press")
    }

    // ---------- Voice tab ----------

    private fun setupVoice(view: View) {
        val voiceText = view.findViewById<TextView>(R.id.voiceText)
        val toggle = view.findViewById<Button>(R.id.btnVoiceToggle)
        voice = VoiceTypingController(this) { text, isFinal ->
            voiceText.text = text
            if (isFinal) {
                getSharedPreferences("voice", MODE_PRIVATE)
                    .edit()
                    .putString("last_text", text)
                    .apply()
                toggle.text = "Start listening"
            }
        }
        toggle.setOnClickListener {
            val controller = voice ?: return@setOnClickListener
            if (controller.listening) {
                controller.stop()
                toggle.text = "Start listening"
            } else {
                val granted = checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) ==
                    PackageManager.PERMISSION_GRANTED
                if (!granted) {
                    toast("Grant microphone permission from the main app first")
                    return@setOnClickListener
                }
                controller.start()
                toggle.text = "Stop"
            }
        }
        view.findViewById<Button>(R.id.btnCopyText).setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("voice_text", voiceText.text))
            toast("Copied — or insert with the GameKeyboard '🎤 Text' key")
        }
    }

    // ---------- Apps tab ----------

    private fun setupApps(view: View) {
        val webApps = mapOf(
            R.id.appDiscord to ("Discord" to "https://discord.com/login"),
            R.id.appTelegram to ("Telegram" to "https://web.telegram.org"),
            R.id.appWhatsapp to ("WhatsApp" to "https://web.whatsapp.com")
        )
        webApps.forEach { (id, app) ->
            view.findViewById<Button>(id).setOnClickListener {
                openFloating(FloatingWebWindow(this, wm, app.first, app.second))
            }
        }
        view.findViewById<Button>(R.id.appBrowser).setOnClickListener {
            openFloating(
                FloatingWebWindow(this, wm, "Browser", "https://www.google.com", showUrlBar = true)
            )
        }
        view.findViewById<Button>(R.id.appCalculator).setOnClickListener {
            openFloating(CalcWindow(this, wm))
        }
    }

    private fun openFloating(window: FloatingWindow) {
        floatingWindows.add(window)
        window.show()
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
