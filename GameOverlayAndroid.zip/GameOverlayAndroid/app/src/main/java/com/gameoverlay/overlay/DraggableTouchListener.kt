package com.gameoverlay.overlay

import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.abs

/**
 * Makes any overlay window draggable. If the finger moves less than the
 * tap threshold, the gesture is treated as a click and [onClick] fires.
 */
class DraggableTouchListener(
    private val wm: WindowManager,
    private val view: View,
    private val params: WindowManager.LayoutParams,
    private val onClick: () -> Unit
) : View.OnTouchListener {

    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var moved = false

    override fun onTouch(v: View, event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX
                downY = event.rawY
                startX = params.x
                startY = params.y
                moved = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - downX
                val dy = event.rawY - downY
                if (abs(dx) > 10 || abs(dy) > 10) moved = true
                if (moved) {
                    params.x = startX + dx.toInt()
                    params.y = startY + dy.toInt()
                    wm.updateViewLayout(view, params)
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!moved) {
                    v.performClick()
                    onClick()
                }
                return true
            }
        }
        return false
    }
}
