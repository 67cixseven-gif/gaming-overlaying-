package com.gameoverlay.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.GridLayout
import android.widget.TextView
import com.gameoverlay.R

/** Draggable mini calculator floating above the game. */
class CalcWindow(
    private val context: Context,
    private val wm: WindowManager
) : FloatingWindow {

    private var view: View? = null
    private var expression = ""

    override fun show() {
        if (view != null) return
        val v = LayoutInflater.from(context).inflate(R.layout.calc_view, null)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 60
            y = 300
        }

        val display = v.findViewById<TextView>(R.id.calcDisplay)
        v.findViewById<View>(R.id.calcHeader)
            .setOnTouchListener(DraggableTouchListener(wm, v, lp) {})
        v.findViewById<Button>(R.id.calcClose).setOnClickListener { dismiss() }

        val grid = v.findViewById<GridLayout>(R.id.calcGrid)
        val keys = listOf(
            "7", "8", "9", "/",
            "4", "5", "6", "*",
            "1", "2", "3", "-",
            "0", ".", "=", "+",
            "C", "(", ")", "⌫"
        )
        keys.forEach { key ->
            val button = Button(context).apply {
                text = key
                layoutParams = GridLayout.LayoutParams(
                    GridLayout.spec(GridLayout.UNDEFINED, 1f),
                    GridLayout.spec(GridLayout.UNDEFINED, 1f)
                ).apply { width = 0 }
                setOnClickListener {
                    when (key) {
                        "C" -> expression = ""
                        "⌫" -> expression = expression.dropLast(1)
                        "=" -> expression = try {
                            val result = evaluate(expression)
                            if (result % 1.0 == 0.0) result.toLong().toString()
                            else result.toString()
                        } catch (e: Exception) {
                            "Error"
                        }
                        else -> expression += key
                    }
                    display.text = expression
                }
            }
            grid.addView(button)
        }

        wm.addView(v, lp)
        view = v
    }

    override fun dismiss() {
        view?.let { runCatching { wm.removeView(it) } }
        view = null
    }

    /** Small safe expression evaluator: + - * / parentheses decimals. */
    private fun evaluate(expr: String): Double {
        val tokens = mutableListOf<String>()
        var pos = 0
        while (pos < expr.length) {
            val c = expr[pos]
            when {
                c.isDigit() || c == '.' -> {
                    val start = pos
                    while (pos < expr.length && (expr[pos].isDigit() || expr[pos] == '.')) pos++
                    tokens.add(expr.substring(start, pos))
                }
                c in "+-*/()" -> {
                    tokens.add(c.toString())
                    pos++
                }
                c == ' ' -> pos++
                else -> throw IllegalArgumentException("Bad character: $c")
            }
        }
        if (tokens.isEmpty()) throw IllegalArgumentException("Empty expression")

        var i = 0
        fun peek() = tokens.getOrNull(i)
        fun next() = tokens.getOrNull(i++)

        fun parseFactor(): Double = when (val t = next()) {
            "(" -> {
                val value = parseExpr()
                next() // consume ')'
                value
            }
            "-" -> -parseFactor()
            null -> throw IllegalArgumentException("Unexpected end")
            else -> t.toDouble()
        }

        fun parseTerm(): Double {
            var value = parseFactor()
            while (peek() == "*" || peek() == "/") {
                val op = next()
                val right = parseFactor()
                value = if (op == "*") value * right else value / right
            }
            return value
        }

        fun parseExpr(): Double {
            var value = parseTerm()
            while (peek() == "+" || peek() == "-") {
                val op = next()
                val right = parseTerm()
                value = if (op == "+") value + right else value - right
            }
            return value
        }

        val result = parseExpr()
        if (i != tokens.size) throw IllegalArgumentException("Invalid expression")
        return result
    }
}
