package com.gameoverlay.keys

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class KeyMapping(val label: String, val x: Int, val y: Int)

/** Persists key → touch-point mappings as JSON in SharedPreferences. */
object KeyMapper {

    private const val PREFS = "key_mapper"
    private const val KEY = "mappings"

    fun load(context: Context): MutableList<KeyMapping> {
        val json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(json)
        val out = mutableListOf<KeyMapping>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(KeyMapping(o.getString("label"), o.getInt("x"), o.getInt("y")))
        }
        return out
    }

    private fun save(context: Context, list: List<KeyMapping>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("label", it.label).put("x", it.x).put("y", it.y))
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY, arr.toString())
            .apply()
    }

    fun add(context: Context, mapping: KeyMapping) {
        val list = load(context)
        list.removeAll { it.label == mapping.label }
        list.add(mapping)
        save(context, list)
    }

    fun remove(context: Context, label: String) {
        save(context, load(context).filterNot { it.label == label })
    }
}
