package com.gameoverlay.boost

import android.app.ActivityManager
import android.app.NotificationManager
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings

/** RAM stats, background-app cleanup and gaming DND toggle. */
object BoostManager {

    fun memorySummary(context: Context): String {
        val am = context.getSystemService(ActivityManager::class.java)
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        val totalMb = info.totalMem / (1024 * 1024)
        val availMb = info.availMem / (1024 * 1024)
        val usedPct = 100 - info.availMem * 100 / info.totalMem
        return "RAM: ${availMb} MB free of ${totalMb} MB ($usedPct% used)"
    }

    /**
     * Asks the system to close background processes of installed
     * third-party apps. Android decides what actually gets killed;
     * foreground/system apps are never touched.
     */
    fun boost(context: Context): String {
        val am = context.getSystemService(ActivityManager::class.java)
        val pm = context.packageManager
        val apps = if (Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledApplications(0)
        }
        var signaled = 0
        apps.forEach { app ->
            val isSystem = app.flags and ApplicationInfo.FLAG_SYSTEM != 0
            if (!isSystem && app.packageName != context.packageName) {
                runCatching {
                    am.killBackgroundProcesses(app.packageName)
                    signaled++
                }
            }
        }
        System.gc()
        return "Boost done — signaled $signaled background apps to close"
    }

    fun toggleDnd(context: Context): String {
        val nm = context.getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            context.startActivity(
                Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return "Grant Do-Not-Disturb access, then try again"
        }
        val newFilter =
            if (nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALL) {
                NotificationManager.INTERRUPTION_FILTER_NONE
            } else {
                NotificationManager.INTERRUPTION_FILTER_ALL
            }
        nm.setInterruptionFilter(newFilter)
        return if (newFilter == NotificationManager.INTERRUPTION_FILTER_NONE) {
            "Gaming DND ON — notifications silenced"
        } else {
            "Gaming DND OFF — notifications restored"
        }
    }
}
