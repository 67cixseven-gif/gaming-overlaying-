package com.gameoverlay

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.gameoverlay.overlay.OverlayService

class MainActivity : AppCompatActivity() {

    companion object {
        private const val REQ_PERMISSIONS = 42
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnOverlayPermission).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            } else {
                toast("Overlay permission already granted")
            }
        }

        findViewById<Button>(R.id.btnMicPermission).setOnClickListener {
            val needed = mutableListOf(android.Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) needed.add(android.Manifest.permission.POST_NOTIFICATIONS)
            val missing = needed.filter {
                checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
            }
            if (missing.isNotEmpty()) {
                requestPermissions(missing.toTypedArray(), REQ_PERMISSIONS)
            } else {
                toast("Microphone permission already granted")
            }
        }

        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            toast("Find 'Game Overlay' in the list and switch it ON")
        }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                toast("Grant the display-over-apps permission first")
                return@setOnClickListener
            }
            ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
            toast("Overlay started — switch to your game")
        }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            startService(
                Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP)
            )
        }
    }

    override fun onResume() {
        super.onResume()
        val overlay = Settings.canDrawOverlays(this)
        val mic = checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        findViewById<TextView>(R.id.statusText).text = buildString {
            append("Setup checklist:\n")
            append(if (overlay) "✅ Display over other apps\n" else "❌ Display over other apps\n")
            append(if (mic) "✅ Microphone (voice typing)\n" else "❌ Microphone (voice typing)\n")
            append("ℹ️ Key Mapper: enable 'Game Overlay' in Accessibility settings\n")
            append("ℹ️ GameKeyboard: enable in System → Languages → On-screen keyboard")
        }
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
